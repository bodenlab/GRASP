#' Data to be included in this package
#' 
#' @name asrStructure
#' @docType data
#' @usage asrStructure
#' @keywords data

NULL