# -*- coding: utf-8 -*-
"""
Created on Fri Mar 11 10:26:03 2016

@author: aesseb
"""

f = open("MAFFT_CYP3_new_Vertebrate_indexed7b.fasta")
f = f.readlines()
out = open("MAFFT_CYP3_new_Vertebrate_indexed7b_short.fasta", 'w')
for line in f:
    if line.startswith(">"):
        out.write(line)
        next = True
        continue
#    line = line.strip()
    if next:
        line = str(line)[0:11]
        out.write(line + "\n")
        next = False
out.close()
